import enum


class accounttype(enum.Enum):
   Member = 1
   Manager = 2
