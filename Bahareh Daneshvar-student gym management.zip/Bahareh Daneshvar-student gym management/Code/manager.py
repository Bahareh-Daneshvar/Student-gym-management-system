
from account import  Account
from accounttype import  accounttype
from club import  Club

class Manager(Account):
    __islogined=False
    def __init__(self,id, name, tell,username,password):
        super().__init__(username,password,accounttype.Member)
        self.id = id
        self.__name = name
        self.__tell = tell

    def login(self):
        for mem in Club.managerList:
            if mem.username == self.username and mem.password == self.password:
                self.__islogined
                return True
        return False

    def register(self):
        if self.__name == '' or self.__tell == '' :
            return False

        Club.managerList.append(self)
        return True

    @property
    def Name(self):
        return self.__name

    @Name.setter
    def Name(self, new_name):
        if new_name != '':
            self.__name = new_name
        else:
            print("Please enter a valid name")

    @property
    def Tell(self):
        return self.__tell

    @Tell.setter
    def Tell(self, new_tell):
        if len(new_tell) != 11:
            self.__tell = new_tell
        else:
            print("Please enter a valid tell")