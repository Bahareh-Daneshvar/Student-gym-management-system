
from member import  Member
from club import  Club
from service import  Service
from manager import  Manager
from reservation_service import  Reservation
from transaction import  Transaction

if __name__ == "__main__":

    c = Club(1,'Sport Club',448484,'London')

    m = Manager(1,'Maryam','7848874','manager',123)
    m.register()
    m.login()

    print ("#Manager Added")

    m = Member(25, 'sara', '4412358742691', 'member', '123')
    m.register()
    m.login()

    c.add_service(Service(1, 'sportA', '2023-18-01', '2023-18-02', 456, True))
    c.add_service(Service(2, 'sportB', '2023-18-02', '2023-18-03', 220, False))
    c.add_service(Service(3, 'sportC', '2023-18-01', '2023-18-02', 159, True))

    c.show_all_service()

    print('#Services Added')
    t = Transaction(1,1,159,'14848484881848')
    r = Reservation(1,25,3,1)
    result =r.new_reservation()
    print('#Result Reservation:' , result)

    m.load_reservation_list()

    pass