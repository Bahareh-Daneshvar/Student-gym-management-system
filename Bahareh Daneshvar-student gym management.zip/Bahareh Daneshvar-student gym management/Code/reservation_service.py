

from club import  Club
from datetime import  datetime
from member import  Member

class Reservation:
    def __init__(self,id, customerid, serviceid,transaction_id):
        self.id = id
        self.customerid = customerid
        self.serviceid = serviceid
        self.today = datetime.now()
        self.transaction_id = transaction_id

    def new_reservation(self):
        if self.check_member() == False:
            return False

        if self.check_service() == False:
            return False

        Club.reservationList.append(Reservation(self.id,self.customerid,self.serviceid,self.transaction_id))
        return  True

    def check_member(self):
        for mem in Club.memberList:
            if mem.id == self.customerid:
                return True
        return False

    def check_service(self):
        for mem in Club.serviceList:
            if mem.Active == True and mem.id == self.serviceid:
                return True
        return False