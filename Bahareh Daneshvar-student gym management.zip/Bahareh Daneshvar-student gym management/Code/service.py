
class Service:
    def __init__(self,id, name, fromdate,todate,price,active):
        self.id = id
        self.name = name
        self.fromdate = fromdate
        self.todate = todate
        if price >= 0 :
            self.__price = price
        else:
            self.__price = 0
        self.__active=active

    def check_overlapp(self):
        if self.fromdate > self.todate:
            return False
        if self.todate < self.fromdate:
            return False
        return True

    def active(self):
        self.__active = True

    def deactive(self):
        self.__active = False

    @property
    def Active(self):
        return self.__active

    @Active.setter
    def Active(self, new_active):
        if type(new_active,bool):
            self.__active = new_active
        else:
            raise Exception("Please enter a valid active value")

    @property
    def Price(self):
        return self.__price

    @Price.setter
    def Price(self, new_price):
        if new_price >= 0 :
            self.__price = new_price
        else:
            raise Exception("Please enter a valid price value")
