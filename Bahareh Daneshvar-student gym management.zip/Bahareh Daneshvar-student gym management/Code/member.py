
from account import  Account
from accounttype import  accounttype
from club import  Club

class Member(Account):
    _reservation_list=[]
    __islogined = False
    def __init__(self,id, name, tell,username,password):
        super().__init__(username,password,accounttype.Member)
        self.id = id
        self.name = name
        self.tell = tell

    def register(self):
        if self.name == '' or self.tell == '' :
            return False
        Club.memberList.append(self)
        return True

    def login(self):
        for mem in Club.memberList:
            if mem.username == self.username and mem.password == self.password:
                self.__islogined = True
                return True
        return False

    def load_reservation_list(self):
        if self.__islogined == False:
            return False
        for mem in Club.reservationList:
            if mem.customerid == self.id:
                print("reserve ID:",mem.customerid ," ServiceID:" , mem.serviceid , "Today:" ,mem.today)
        return True
        pass