from member import  Member
from club import  Club

import unittest

class member_testing(unittest.TestCase):

  def test_register_member(self):

      m = Member(123, "test","34444433","bahar","123")
      excpected=True
      actual= m.register()
      self.assertEqual(excpected, actual)


  def test_login_student(self):
    m = Member("4433", "bahar", "34444433", "bahar", "123")
    m.register()
    excpected = True
    actual = m.login()

    self.assertEqual(excpected, actual)

if __name__ == '__main__':
    unittest.main()