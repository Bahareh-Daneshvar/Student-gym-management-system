

from abc import (ABC,abstractmethod)
from accounttype import  accounttype

class Account(ABC):
    @abstractmethod
    def __init__(self,username,password,type:accounttype):
        if (type != accounttype.Manager and type != accounttype.Member):
            raise Exception('You can not set another type!')
        self.username=username
        self.password = password
        self.type = type

    @abstractmethod
    def login(self):
        pass

    @abstractmethod
    def register(self):
        pass
