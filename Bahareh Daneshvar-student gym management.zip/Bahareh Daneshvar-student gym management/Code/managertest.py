from manager import  Manager
from club import  Club

import unittest

class manager_testing(unittest.TestCase):

  def test_register_member(self):

      m = Manager(123, "test","34444433","admin","123")
      excpected=True
      actual= m.register()
      self.assertEqual(excpected, actual)


  def test_login_student(self):
    m = Manager("4433", "bahar", "34444433", "admin", "123")
    m.register()
    excpected = True
    actual = m.login()
    self.assertEqual(excpected, actual)

if __name__ == '__main__':
    unittest.main()