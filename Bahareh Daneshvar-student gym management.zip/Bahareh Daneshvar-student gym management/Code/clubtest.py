from member import  Member
from club import  Club
from service import  Service

import unittest

class club_testing(unittest.TestCase):

  def test_create_instant(self):

      try:
          ac = Club(11,'test','8848484','london')
          raise
      except:
          pass


  def test_show_all_service(self):
      c = Club(11, 'test', '8848484', 'london')
      s = Service(11,'test1','2023-18-01','2023-01-22',34,True)
      c.add_service(s)
      excpected = 1
      actual = len(c.show_all_service())
      self.assertEqual(excpected, actual)

if __name__ == '__main__':
    unittest.main()