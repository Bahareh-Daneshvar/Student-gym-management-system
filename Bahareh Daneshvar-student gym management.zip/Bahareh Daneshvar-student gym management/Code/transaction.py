
from club import  Club
from datetime import datetime


class Transaction:
    def __init__(self,id, orderID, price,cardnumber):
        self.id = id
        self.__orderID = orderID
        self.price = price
        self.today = datetime.now()
        self.__cardnumber = cardnumber

    def cancel(self):
        Club.transactionList.remove(self)

    def add(self):
        if self.check_order() == False:
            return  False
        Club.transactionList.append(self)
        return True

    def check_order(self):
        for mem in Club.reservationList:
            if mem.id == self.__orderID:
                return True
        return False

    @property
    def OrderID(self):
        return self.__orderID

    @OrderID.setter
    def Active(self, new_orderID):
        if self.__orderID != 0 :
            self.__orderID = new_orderID
        else:
            raise Exception("Please enter a valid orderID value")

    @property
    def CardNumber(self):
        return self.__cardnumber

    @CardNumber.setter
    def CardNumber(self, new_cardnumber):
        if self.__cardnumber != 0:
            self.__cardnumber = new_cardnumber
        else:
            raise Exception("Please enter a valid card number value")