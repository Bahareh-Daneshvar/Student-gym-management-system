from Singleton import  Singleton
from service import  Service

class Club(metaclass=Singleton):
    memberList=[]
    serviceList=[]
    managerList=[]
    reservationList=[]
    transactionList=[]
    def __init__(self,id, title, tell,address):
        self.id = id
        self.__title = title
        self.__tell = tell
        self.__address = address

    @property
    def Title(self):
        return self.__title

    @Title.setter
    def Title(self, new_title):
        if new_title >= 0:
            self.__title = new_title
        else:
            raise Exception("Please enter a valid title value")

    @property
    def Tell(self):
        return self.__tell

    @Tell.setter
    def Tell(self, new_tell):
        if len(new_tell) == 11:
            self.__tell = new_tell
        else:
            raise Exception("Please enter a valid tell value")

    @property
    def Address(self):
        return self.__address

    @Address.setter
    def Address(self, new_address):
        if self.__address != '':
            self.__address = new_address
        else:
            raise Exception("Please enter a valid address value")

    def show_all_service(self):
        activeService =[]
        for s in Club.serviceList:
            if s.Active == True:
                activeService.append(s)
                print ("srviceID:",s.id," ServiceName:" , s.name , " Price:" , s.Price)
        return activeService

    def add_service(self,service):
        Club.serviceList.append(service)
