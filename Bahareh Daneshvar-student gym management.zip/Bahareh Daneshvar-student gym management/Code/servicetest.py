from club import  Club
from service import  Service

import unittest

class service_testing(unittest.TestCase):

  def test_check_overlapp(self):

      s = Service(11,'test1','2023-18-01','2023-01-06',34,True)
      excpected = s.check_overlapp()
      actual = False
      self.assertEqual(excpected, actual)


  def test_can_set_zero_negative_value_price(self):
          s = Service(11, 'test1', '2023-18-01', '2024-01-22', -2, True)
          excpected = 0
          actual = s.Price
          self.assertEqual(excpected, actual)
          s.Price = 2
          excpected = 2
          actual = s.Price
          self.assertEqual(excpected, actual)

if __name__ == '__main__':
    unittest.main()