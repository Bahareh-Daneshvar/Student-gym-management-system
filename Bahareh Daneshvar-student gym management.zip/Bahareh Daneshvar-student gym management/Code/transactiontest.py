from club import  Club
from service import  Service
from reservation_service import Reservation
from member import  Member
from transaction import  Transaction
import unittest

class reservation_testing(unittest.TestCase):

  def test_new_reservation(self):

      m = Member(123, "test","34444433","bahar","123")
      s = Service(11, 'test1', '2023-18-01', '2024-01-22', -2, True)
      r = Reservation(1,123,11,1)
      t = Transaction(1,1,123,13323)

      Club.add_service(self,service=s)
      m.register()
      r.new_reservation()

      excpected = True
      actual =t.add()
      self.assertEqual(excpected, actual)

if __name__ == '__main__':
    unittest.main()